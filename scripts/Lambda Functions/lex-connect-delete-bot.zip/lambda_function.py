import boto3
import time

client = boto3.client('lex-models')

def lambda_handler(event, context):
    # TODO implement
    bot_Name = 'BookAppointment'
    bot_Alias = 'BookAppointment'
    intent_1 = 'BookAppointment'
    intent_2 = 'CheckAppointment'
    client.delete_bot_alias(name = bot_Alias, botName = bot_Name)
    time.sleep(10)
    client.delete_bot(name= bot_Name)
    time.sleep(10)
    client.delete_intent(name = intent_1)
    time.sleep(10)
    client.delete_intent(name = intent_2)
    time.sleep(10)
    return ('Delete Done')
